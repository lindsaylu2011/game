﻿# 游戏的脚本可置于此文件中。

# 声明此游戏使用的角色。颜色参数可使角色姓名着色。

define ng = Character("南宫")

# 游戏在此开始。
screen txt1():
    text "禁止使用游戏投资者姓名" xalign 0.5 yalign 0.5 size 100 color "#ff0000" 
screen txt2():
    text "你没有拒绝的权利" xalign 0.5 yalign 0.5 size 100 color "#ff0000" 
transform video_center:
    xalign 0.5
    yalign 0.5

image zbcg = Movie(play="videos/zbcg.webm")

image xz = Movie(play="videos/xz.webm")

image ys = Movie(play="videos/ys.webm")
image zgrnf = Movie(play="videos/zgrnf.webm")

label start:

    # 显示一个背景。此处默认显示占位图，但您也可以在图片目录添加一个文件
    # （命名为 bg room.png 或 bg room.jpg）来显示。
    scene black
    python:
        user_name = renpy.input("请输入名字：",length = 32)
    if user_name=="南宫黛雨":
        show zbcg at video_center
        #$ renpy.movie_cutscene("videos/zbcg.webm")
        pause 1.5
        show screen txt1
        pause 1.5
        return
    show qj
    with dissolve
    menu:
        "在一个月黑风高的中午，你收到了来自老朋友南宫的请柬"
        "打开信封":
            pass
    ng "早上好！亲爱的【用户昵称已违规】，我在我的饭店举办了一场宴会，希望你能完整的过来赴约！"
    ng "——南宫黛雨"
    menu:
        "要去赴约吗？"
        "去":
            pass
        "不去":
            scene black
            show zbcg at video_center
            pause 1.5
            show screen txt2
            pause 1.5
            return
    scene jiejing
    with  fade
    "你来到了饭店附近"
    scene jinggai
    with fade
    "门前有个井盖"
    menu:
        "要去踩吗？"
        "踩":
            jump s1
        "不踩":
            pass
    scene fddm
    with fade
    "这里有一个旋转门和一个侧门"
    menu:
        "要从哪个门进入呢"
        "旋转门":
            "你进入了旋转门"
            "刚刚踏进去"
            scene lx
            with fade
            "你就被旋转门一巴掌扇飞了"
            "结局:漫游"
            scene black
            show zgrnf at video_center
            pause 15
            return
        "侧门":
            pass
    scene fddt
    with fade
    "你顺利的进入了饭店"
    show yx
    with dissolve
    "工作人员好像忘把音响关掉了"
    "音响放着音乐很吵"
    menu:
        "要去关掉吗"
        "关掉":
            play music "yp.mp3"
            "结局:幽蓝边界"
            "你被幽蓝边界吞噬了"
            "南宫想这大概是因为你没有更新Phigros游玩第九章导致的"
            return
        "不关":
            pass
    "音响没电，音乐自己停了"
    hide yx
    $ f=1
    "南宫的饭局在2楼"
    while f==1:
        menu:
            "选择一种方式上楼"
            "坐电梯":
                jump s2
            "走旋转楼梯":
                "你走上旋转楼梯"
                "旋转楼梯开始旋转"
                show black
                show xz at video_center
                pause 11
                "你被转晕了，走下了旋转楼梯"
                scene fddt
                with fade
            "走安全通道楼梯":
                scene lt
                with fade
                "你进入了安全通道楼梯"
                "安全通道里没开灯"
                menu:
                    "要打开灯吗？"
                    "要":
                        scene black
                        with fade
                        show ys at video_center
                        pause 6
                        "结局:原神"
                        "白光一闪，原神启动"
                        "原神7.1更新还不赶紧去肝主线😡"
                        return
                    "不要":
                        $ f=2

            "中国人能飞 飞上去":
                """
                你使用喷气背包飞上去

                喷气背包出故障了😭

                你掉了下去
                """
    scene fdel
    with fade
    "你到了2楼"
    "你见到了南宫"
    ng "[user_name]，你终于来了！"
    ng "在这张人员表上签个字，你就可以进去了"
    show bg:
        yalign 0.2
        xalign 0.7
        zoom 4.0
    python:
        user_name2 = renpy.input("",length = 32)
    hide bg
    "你写完了名字，向着包间走去"
    if user_name2==user_name:
        scene red
        pause 0.3
        scene fdel
        "你再起不能"
        ng "不要随便把自己的真名暴露出来哦~"
        ng "实在是太懈怠了"
        "你想起了南宫之前说的话"
        ng "只有强者才能来我的餐厅吃上饭"
        scene black
        with fade
        """
        结局:中道崩殂

        写名字的纸是从死亡笔记上撕下来的

        你这种人在慈航市活不过3秒
        """
        return
    user_name "不知道南宫都做了些什么"
    "包间里已经有了其他人"
    "这些人一副生不如死的模样"
    user_name "怎么回事"
    "你看见其中一人还在不停往外"
    show xc:
        yalign 0.2
        xalign 0.5
    with dissolve
    "喷香菜"
    "有人在背后拍了你一下"
    "是南宫"
    ng "欢迎来到我的香菜定制局呀~"
    ng "这里有香菜拌折耳根，香菜拌香菜，香菜蘸香菜酱，炸香菜，炒香菜，腌香菜，
    煮香菜，烤香菜，秘制香菜，红烧香菜，清蒸香菜，生腌香菜，香菜馒头，香菜面，
    香菜米饭，香菜小蛋糕，香菜薄荷味果茶，香菜棒棒糖，香菜棉花糖，香菜辣条，
    香菜榨汁，折耳根拌香菜……"
    ng "要吃完哦，不许浪费粮食呢~"
    """
    好结局:香菜

    你不知道你是怎么出饭店的

    你也不知道自己是否还活着

    只知道香菜拌香菜香菜蘸香菜蘸香菜拌香菜的香菜所以香菜好吃的香菜和香菜
    """
    return

label s1:
    scene black
    with fade
    "你一脚踩下井盖"
    scene houshi
    with fade
    "结局:后室"
    "剧本好像出了什么问题"
    "你大概很难吃上南宫的饭了"
    return

label s2:
    scene dtnb
    with fade
    "你进入了电梯"
    "电梯似乎卡住了"
    "……"
    menu:
        "要怎么办？"
        "按求救铃":
            """
            铃响了半天没有任何动静

            南宫的饭店没有请保安

            你记得她当时是这么说的
            """
            ng "只有强者才能来我的餐厅吃上饭"
            menu:
                "要怎么办？"
                "撬开电梯门":
                    jump s3
        "撬开电梯门":
            jump s3

label s3:
    "门开了"
    scene ysj
    with fade
    user_name "这给我干哪来了？"
    """
    结局:异地

    你穿越到了异世界

    你恐怕很难吃上南宫的饭了
    """
    return